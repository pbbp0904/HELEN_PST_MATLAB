clear; clc; close all;
tic
DirectoryLocation = "GroundTest1Data";
PayloadPrefixes = {"1RED", "2GREEN", "3YELLOW", "4BLUE"};
PayloadColors = {"Red", "Green", "Yellow", "Blue"};
EnvPrefix = "ENV";
RadPrefixes = {"RAD_PEAK", "RAD_TAIL", "RAD_TIME"};

parseEnv = 1; parseRad = 1; parseEFM = 0;

% Load and Parse Environmental Data
if (parseEnv)
   PayloadEnvData = parseEnvData(DirectoryLocation, PayloadPrefixes, EnvPrefix);
end

% Load and Parse Radiation Data
if (parseRad)
    PayloadRadData = parseRadData(DirectoryLocation, PayloadPrefixes, RadPrefixes);
end

% Load and Parse EFM Data
if(parseEFM)
    
end


% Summarize Data
[Stats, Graphs] = summarizeData(PayloadEnvData, PayloadRadData, PayloadPrefixes, PayloadColors);
toc